# Campus Feed App

A campus social feed application with AI-powered post classification using Google Gemini.

## Setup

### Backend

1. Navigate to the backend directory:
```bash
cd backend
```

2. Install dependencies:
```bash
npm install
```

3. Create a `.env` file with your configuration:
```env
GOOGLE_API_KEY=your_gemini_api_key_here
MONGODB_URI=mongodb://localhost:27017  # optional
MONGODB_DB=campus-feed  # optional
PORT=4000
```

4. Get your Gemini API key from [Google AI Studio](https://makersuite.google.com/app/apikey)

5. Start the backend:
```bash
npm start
```

### Frontend

1. Navigate to the frontend directory:
```bash
cd frontend
```

2. Install dependencies:
```bash
npm install
```

3. Start the frontend:
```bash
npm start
```

## Features

- AI-powered post classification using Google Gemini
- Three post types: Events, Lost & Found, Announcements
- RSVP system for events
- MongoDB integration (with in-memory fallback)

## AI Integration

The app uses **Google Gemini (gemini-2.0-flash-exp)** to automatically classify and extract structured data from natural language prompts.
