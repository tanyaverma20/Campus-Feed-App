import React from 'react';

function Composer({ input, onChange, onSubmit, loading }) {
  return (
    <div className="composer">
      <div className="composer-header">what would you like to share?</div>
      <div className="prompt-wrapper">
        <textarea
          className="prompt"
          placeholder="Type in plain English… (e.g., Lost wallet near library yesterday)"
          value={input}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
              e.preventDefault();
              onSubmit();
            }
          }}
        />
        <button
          className="icon-button"
          aria-label="Submit"
          disabled={!input.trim() || loading}
          onClick={onSubmit}
          title="Submit (Cmd/Ctrl+Enter)"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 12L21 3L12 21L11 13L3 12Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
          </svg>
        </button>
      </div>
      <div className="hint">Use Cmd/Ctrl+Enter to submit</div>
    </div>
  );
}

export default Composer;


