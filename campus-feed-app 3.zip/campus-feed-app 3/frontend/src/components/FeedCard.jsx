import React from 'react';

function FeedCard({ post, onRsvp }) {
  return (
    <div className="card two-pane">
      <div className="pane left">
        <div className="image-placeholder" />
      </div>
      <div className="pane right">
        {post.type === 'event' && (
          <>
            <div className="headline"><u>New Event:</u> Mahesh shared an event {timeAgo(post.createdAt)}</div>
            <div className="title">{post.data.description}</div>
            <div className="meta">At location: {post.data.location}</div>
            <div className="meta">{post.data.date}</div>
            <div className="rsvp">
              <button onClick={() => onRsvp(post.id, 'going')}>Going ({post.rsvpCounts.going})</button>
              <button onClick={() => onRsvp(post.id, 'interested')}>Maybe ({post.rsvpCounts.interested})</button>
              <button onClick={() => onRsvp(post.id, 'not_going')}>Not going ({post.rsvpCounts.not_going})</button>
            </div>
          </>
        )}
        {post.type === 'lost_found' && (
          <>
            <div className="pill">Lost & Found: posted {timeAgo(post.createdAt)}</div>
            <div className="title">{post.data.itemDescription}</div>
            <div className="meta">At location: {post.data.location}</div>
            {post.data.imageUrl ? (
              <img alt="attachment" className="attachment" src={post.data.imageUrl} />
            ) : null}
          </>
        )}
        {post.type === 'announcement' && (
          <>
            <div className="pill">Announcement: posted {timeAgo(post.createdAt)}</div>
            <div className="title">{post.data.department}</div>
            <div className="meta">{post.data.description}</div>
            {post.data.attachmentUrl ? (
              String(post.data.attachmentUrl).startsWith('data:application/pdf') ? (
                <a href={post.data.attachmentUrl} target="_blank" rel="noreferrer">View PDF</a>
              ) : (
                <img alt="attachment" className="attachment circular" src={post.data.attachmentUrl} />
              )
            ) : null}
          </>
        )}
      </div>
    </div>
  );
}

function timeAgo(iso) {
  try {
    const then = new Date(iso).getTime();
    const now = Date.now();
    const diff = Math.max(0, Math.floor((now - then) / 1000));
    if (diff < 60) return `${diff}s ago`;
    const m = Math.floor(diff / 60);
    if (m < 60) return `${m}m ago`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h}h ago`;
    const d = Math.floor(h / 24);
    return `${d}d ago`;
  } catch {
    return '';
  }
}

export default FeedCard;


