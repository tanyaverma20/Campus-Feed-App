import React from 'react';

function Preview({ preview, onFieldChange, onPublish, onDiscard, publishing }) {
  if (!preview?.type) return null;

  async function handleFileToDataUrl(file, field) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      onFieldChange(field, reader.result);
    };
    reader.readAsDataURL(file);
  }

  return (
    <div className="preview">
      <h2>Does everything look good?</h2>
      <div className="two-pane">
        <div className="pane left">
          <div className="image-placeholder" />
        </div>
        <div className="pane right">
          {preview.type === 'event' && (
            <div className="stack">
              <div className="pill">Event</div>
              <label>
                At location:
                <input
                  value={preview.data.location || ''}
                  onChange={(e) => onFieldChange('location', e.target.value)}
                />
              </label>
              <label>
                Date
                <input
                  type="datetime-local"
                  value={preview.data.date || ''}
                  onChange={(e) => onFieldChange('date', e.target.value)}
                />
              </label>
              <label>
                Description
                <input
                  value={preview.data.description || ''}
                  onChange={(e) => onFieldChange('description', e.target.value)}
                />
              </label>
              <div className="rsvp inline">
                <span>RSVP:</span>
                <button disabled>Going</button>
                <button disabled>Interested</button>
                <button disabled>Not Going</button>
              </div>
            </div>
          )}
          {preview.type === 'lost_found' && (
            <div className="stack">
              <div className="pill">Lost & Found</div>
              <label>
                Item Description
                <input
                  value={preview.data.itemDescription || ''}
                  onChange={(e) => onFieldChange('itemDescription', e.target.value)}
                />
              </label>
              <label>
                At location:
                <input
                  value={preview.data.location || ''}
                  onChange={(e) => onFieldChange('location', e.target.value)}
                />
              </label>
              <label>
                Image (optional)
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleFileToDataUrl(e.target.files?.[0], 'imageUrl')}
                />
              </label>
            </div>
          )}
          {preview.type === 'announcement' && (
            <div className="stack">
              <div className="pill">Official Announcement</div>
              <label>
                Department
                <input
                  value={preview.data.department || ''}
                  onChange={(e) => onFieldChange('department', e.target.value)}
                />
              </label>
              <label>
                Description
                <input
                  value={preview.data.description || ''}
                  onChange={(e) => onFieldChange('description', e.target.value)}
                />
              </label>
              <label>
                Attachment (image/PDF)
                <input
                  type="file"
                  accept="image/*,application/pdf"
                  onChange={(e) => handleFileToDataUrl(e.target.files?.[0], 'attachmentUrl')}
                />
              </label>
            </div>
          )}
        </div>
      </div>

      <div className="actions">
        <button className="secondary" onClick={onDiscard} disabled={publishing}>Nah! Restart flow</button>
        <button onClick={onPublish} disabled={publishing}>{publishing ? 'Publishing...' : 'Looks good! Post it'}</button>
      </div>
    </div>
  );
}

export default Preview;


