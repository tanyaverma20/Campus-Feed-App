import React from 'react';
import './App.css';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import Composer from './components/Composer';
import Preview from './components/Preview';
import FeedCard from './components/FeedCard';

const initialPreview = { type: null, data: {} };

function App() {
  const [input, setInput] = React.useState('');
  const [loadingAI, setLoadingAI] = React.useState(false);
  const [preview, setPreview] = React.useState(initialPreview);
  const [publishing, setPublishing] = React.useState(false);
  const [feed, setFeed] = React.useState([]);
  const [loadingFeed, setLoadingFeed] = React.useState(false);
  const [error, setError] = React.useState('');
  const location = useLocation();

  const fetchFeed = React.useCallback(async () => {
    setLoadingFeed(true);
    try {
      const res = await fetch('/posts');
      const json = await res.json();
      setFeed(json.posts || []);
    } catch (e) {
      // noop
    } finally {
      setLoadingFeed(false);
    }
  }, []);

  React.useEffect(() => {
    fetchFeed();
  }, [fetchFeed]);

  // If user navigates directly to a compose route, set a default preview type to guide the UI
  React.useEffect(() => {
    if (location.pathname.startsWith('/compose')) {
      if (location.pathname.includes('event')) setPreview((p) => ({ ...p, type: p.type || 'event', data: p.data || {} }));
      if (location.pathname.includes('lost-found')) setPreview((p) => ({ ...p, type: p.type || 'lost_found', data: p.data || {} }));
      if (location.pathname.includes('announcement')) setPreview((p) => ({ ...p, type: p.type || 'announcement', data: p.data || {} }));
    }
  }, [location.pathname]);

  async function interpretWithAI() {
    setError('');
    setLoadingAI(true);
    try {
      const res = await fetch('/ai/interpret', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: input }),
      });
      if (!res.ok) throw new Error('AI request failed');
      const json = await res.json();
      const { preview: p } = json;
      setPreview({ type: p.type, data: p.data || {} });
    } catch (e) {
      setError('Could not interpret the text. Try rephrasing.');
    } finally {
      setLoadingAI(false);
    }
  }

  function updatePreviewField(field, value) {
    setPreview((prev) => ({ ...prev, data: { ...prev.data, [field]: value } }));
  }

  async function publish() {
    setPublishing(true);
    setError('');
    try {
      const res = await fetch('/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: preview.type, data: preview.data }),
      });
      if (!res.ok) throw new Error('Publish failed');
      setPreview(initialPreview);
      setInput('');
      await fetchFeed();
    } catch (e) {
      setError('Failed to publish.');
    } finally {
      setPublishing(false);
    }
  }

  async function rsvp(postId, status) {
    try {
      await fetch(`/posts/${postId}/rsvp`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      await fetchFeed();
    } catch (e) {
      // noop
    }
  }

  return (
    <Routes>
      <Route
        path="/"
        element={(
          <div className="container">
            <h1>feed!</h1>
            <div className="feed">
              <h2>New post on feed</h2>
              {loadingFeed ? <div>Loading...</div> : null}
              {feed.map((p) => (
                <FeedCard key={p.id} post={p} onRsvp={rsvp} />
              ))}
            </div>
            <div className="home-actions">
              <Link className="home-btn" to="/compose">Create Post</Link>
            </div>
          </div>
        )}
      />

      <Route
        path="/compose"
        element={(
          <div className="container">
            <h1>what would you like to share?</h1>
            <Composer input={input} onChange={setInput} onSubmit={interpretWithAI} loading={loadingAI} />
            {error ? <div className="error">{error}</div> : null}
            <Preview
              preview={preview}
              onFieldChange={updatePreviewField}
              onPublish={async () => { await publish(); setPreview(initialPreview); setInput(''); }}
              onDiscard={() => { setPreview(initialPreview); setInput(''); }}
              publishing={publishing}
            />
            <div className="actions"><Link className="secondary" to="/">Back to feed</Link></div>
          </div>
        )}
      />
    </Routes>
  );
}

export default App;
