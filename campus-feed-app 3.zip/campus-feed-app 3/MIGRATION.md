# Migration from OpenAI to Google Gemini

## Changes Made

### 1. Package Updates
- ✅ Installed `@google/generative-ai` package
- ✅ Removed `openai` package

### 2. Code Changes in `backend/index.js`

**Import Statement:**
```javascript
// Before
const OpenAI = require('openai');

// After
const { GoogleGenerativeAI } = require('@google/generative-ai');
```

**API Implementation:**
```javascript
// Before
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const response = await client.chat.completions.create({
  model: 'gpt-4o-mini',
  messages: [
    { role: 'system', content: system },
    { role: 'user', content: user },
  ],
  temperature: 0.2,
});
const content = response.choices?.[0]?.message?.content;

// After
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: 'gemini-2.0-flash-exp' });
const prompt = `${systemPrompt}\n\nPrompt: ${text}`;
const result = await model.generateContent(prompt);
const content = result.response.text();
```

### 3. Environment Variable Change
- Old: `OPENAI_API_KEY`
- New: `GOOGLE_API_KEY`

### 4. Model Used
- Old: `gpt-4o-mini` (OpenAI)
- New: `gemini-1.5-flash` (Google Gemini)

## Setup Instructions

1. Get your Gemini API key from: https://makersuite.google.com/app/apikey

2. Create a `.env` file in the backend directory:
```env
GOOGLE_API_KEY=your_gemini_api_key_here
PORT=4000
```

3. Start the backend:
```bash
cd backend
npm start
```

## Testing
The AI endpoint (`/ai/interpret`) now uses Google Gemini to:
- Classify campus posts into event, lost_found, or announcement
- Extract structured data from natural language prompts
- Return JSON formatted responses

## Benefits of Gemini
- More cost-effective for high-volume usage
- Faster response times with flash model
- Strong multilingual support
- Better structured output generation
