const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const cookieParser = require('cookie-parser');
const { v4: uuidv4 } = require('uuid');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const mongoose = require('mongoose');

dotenv.config();

const app = express();

// MongoDB connection
const mongoUri = process.env.MONGODB_URI;
if (!mongoUri) {
  console.warn('[startup] No MONGODB_URI provided. Falling back to in-memory store.');
}
let PostModel;
let RsvpModel;
async function connectMongo() {
  if (!mongoUri) return;
  await mongoose.connect(mongoUri);
  const PostSchema = new mongoose.Schema({
    type: { type: String, enum: ['event', 'lost_found', 'announcement'], required: true },
    data: { type: mongoose.Schema.Types.Mixed, required: true },
    authorId: { type: String, required: true },
    createdAt: { type: Date, default: Date.now },
  }, { collection: 'posts' });
  const RsvpSchema = new mongoose.Schema({
    postId: { type: mongoose.Schema.Types.ObjectId, ref: 'Post', required: true },
    userId: { type: String, required: true },
    status: { type: String, enum: ['going', 'interested', 'not_going'], required: true },
    updatedAt: { type: Date, default: Date.now },
  }, { collection: 'rsvps' });
  RsvpSchema.index({ postId: 1, userId: 1 }, { unique: true });
  PostModel = mongoose.model('Post', PostSchema);
  RsvpModel = mongoose.model('Rsvp', RsvpSchema);
}
connectMongo().catch((e) => console.error('Mongo connection error', e));

app.use(cors({
  origin: ['http://localhost:3000'],
  credentials: true,
}));
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());

// Simple in-memory store (used only if MongoDB is not configured)
const posts = [];
const rsvps = new Map(); // key: `${postId}:${userId}` -> 'going' | 'interested' | 'not_going'

// Session via cookie
app.use((req, res, next) => {
  if (!req.cookies || !req.cookies.deviceId) {
    const deviceId = uuidv4();
    res.cookie('deviceId', deviceId, { httpOnly: true, sameSite: 'lax' });
    req.deviceId = deviceId;
  } else {
    req.deviceId = req.cookies.deviceId;
  }
  next();
});

app.get('/health', (_req, res) => {
  res.json({ status: 'ok' });
});

// AI interpret endpoint
app.post('/ai/interpret', async (req, res) => {
  try {
    const { text } = req.body || {};
    if (typeof text !== 'string' || text.trim().length === 0) {
      return res.status(400).json({ error: 'text is required' });
    }

    const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY);
    const model = genAI.getGenerativeModel({ model: 'gemma-3-12b-it' });

    const systemPrompt = `You are an assistant that classifies a campus post prompt into one of three types and extracts structured fields.

Types:
- event: requires description, location, date (ISO preferred)
- lost_found: requires itemDescription, location, optional imageUrl (leave empty)
- announcement: requires department, description, optional attachmentUrl

Return strict JSON with shape: { type: 'event'|'lost_found'|'announcement', data: { ...fields } } without any extra commentary.`;

    const prompt = `${systemPrompt}\n\nPrompt: ${text}`;

    const result = await model.generateContent(prompt);
    let content = result.response.text();
    
    // Strip markdown code blocks if present
    content = content.replace(/```json\s*/g, '').replace(/```\s*/g, '').trim();
    
    let parsed;
    try {
      parsed = JSON.parse(content);
    } catch (e) {
      return res.status(502).json({ error: 'AI response parse error', raw: content });
    }

    return res.json({ preview: parsed });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'server_error' });
  }
});

// Create post
app.post('/posts', async (req, res) => {
  const { type, data } = req.body || {};
  if (!type || !data) {
    return res.status(400).json({ error: 'type and data are required' });
  }
  try {
    if (PostModel) {
      const created = await PostModel.create({ type, data, authorId: req.deviceId });
      const post = {
        id: String(created._id),
        type: created.type,
        data: created.data,
        createdAt: created.createdAt.toISOString(),
        authorId: created.authorId,
      };
      return res.status(201).json({ post });
    } else {
      const id = uuidv4();
      const createdAt = new Date().toISOString();
      const post = { id, type, data, createdAt, authorId: req.deviceId };
      posts.unshift(post);
      return res.status(201).json({ post });
    }
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'create_failed' });
  }
});

// List posts
app.get('/posts', async (_req, res) => {
  try {
    if (PostModel) {
      const docs = await PostModel.find({}).sort({ createdAt: -1 }).lean();
      const postIds = docs.map((d) => d._id);
      const rsvpAgg = await RsvpModel.aggregate([
        { $match: { postId: { $in: postIds } } },
        { $group: { _id: { postId: '$postId', status: '$status' }, count: { $sum: 1 } } },
      ]);
      const countsByPost = new Map();
      for (const r of rsvpAgg) {
        const postId = String(r._id.postId);
        const status = r._id.status;
        const entry = countsByPost.get(postId) || { going: 0, interested: 0, not_going: 0 };
        entry[status] = r.count;
        countsByPost.set(postId, entry);
      }
      const postsOut = docs.map((d) => ({
        id: String(d._id),
        type: d.type,
        data: d.data,
        createdAt: d.createdAt.toISOString(),
        authorId: d.authorId,
        rsvpCounts: countsByPost.get(String(d._id)) || { going: 0, interested: 0, not_going: 0 },
      }));
      return res.json({ posts: postsOut });
    } else {
      const enriched = posts.map((p) => {
        let going = 0, interested = 0, not_going = 0;
        if (p.type === 'event') {
          rsvps.forEach((status, key) => {
            if (key.startsWith(`${p.id}:`)) {
              if (status === 'going') going += 1;
              if (status === 'interested') interested += 1;
              if (status === 'not_going') not_going += 1;
            }
          });
        }
        return { ...p, rsvpCounts: { going, interested, not_going } };
      });
      return res.json({ posts: enriched });
    }
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'list_failed' });
  }
});

// RSVP to event
app.post('/posts/:id/rsvp', async (req, res) => {
  const { id } = req.params;
  const { status } = req.body || {};
  if (!['going', 'interested', 'not_going'].includes(status)) {
    return res.status(400).json({ error: 'invalid status' });
  }
  try {
    if (PostModel) {
      const post = await PostModel.findById(id).lean();
      if (!post || post.type !== 'event') return res.status(404).json({ error: 'post_not_found_or_not_event' });
      await RsvpModel.findOneAndUpdate(
        { postId: post._id, userId: req.deviceId },
        { status, updatedAt: new Date() },
        { upsert: true }
      );
      return res.json({ ok: true });
    } else {
      const post = posts.find((p) => p.id === id && p.type === 'event');
      if (!post) return res.status(404).json({ error: 'post_not_found_or_not_event' });
      rsvps.set(`${id}:${req.deviceId}`, status);
      return res.json({ ok: true });
    }
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'rsvp_failed' });
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Backend listening on port ${PORT}`);
});

module.exports = app;


